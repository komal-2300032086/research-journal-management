import React from 'react'

const check = () => {
    
  // ====> in Login section, solve the problem 



  
  return (
    <div>
      just checking   fo code
    </div>
  )
}

export default check
